#!/bin/bash

#Group 4, all members present at class (Emma, Bill, Devon, Clay, Kelvin)

#Total tests, starts from 0 (so setting to 2 means three tests)
TOT_TESTS=30
CURR_TEST=0

#Set TOT_TESTS so that it counts all the way through
let TOT_TESTS=TOT_TESTS+1
while [ $CURR_TEST -ne $TOT_TESTS ]; do
	FILENAMET="./testFiles/input$CURR_TEST.in"
	cat input1.txt | ./replace `cat $FILENAMET` > testFiles/output$CURR_TEST.out
	let CURR_TEST=CURR_TEST+1
done


cat inputs/in1.txt | ./replace '\n' ' ' > outputs/out1.txt
cat inputs/in1.txt | ./replace ' ' '' '\n' > outputs/out2.txt
cat inputs/in5.txt | ./replace '^b' 'p' > outputs/out3.txt
cat inputs/in5.txt | ./replace 'a$' 'p' > outputs/out4.txt
cat inputs/in1.txt | ./replace '@' '\n' > outputs/out5.txt
cat inputs/in5.txt | ./replace 'a?a' 'd' > outputs/out6.txt
cat inputs/in5.txt | ./replace 'a*a' 'b' > outputs/out7.txt
cat inputs/in4.txt | ./replace 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' 'b' > outputs/out8.txt
cat inputs/in5.txt | ./replace 'a' 'd' > outputs/out9.txt
cat inputs/in1.txt | ./replace 's' 'z' > outputs/out10.txt
cat inputs/in1.txt | ./replace 'a' > outputs/out11.txt
cat inputs/in1.txt | ./replace 'S' 'sss' > outputs/out12.txt

cat input1.txt | ./replace '\t' '\7' > outputs/out13.txt
cat input1.txt | ./replace '\n' '\6' > outputs/out14.txt